The top level script for this project is called "main.m".

Overall, I didn't run into too many problems during the assignment 
and the all of the concepts have made sense to me. Being provided the 
majority of the Q interpolation and slerp was incredibly helpful as well. Because of that,
the most difficult part of the project was just getting used to Matlab
programming, 1 based indices, and figuring out how I wanted to read/write data
and store it in matrices.

Overall, I felt the project was a good project. Plenty of time was given to us, and it was 
a good application of some of the concepts we're learning. It was nice being provided slerp, 
Q interpolation, R to Q, and Q to R scripts, but also cool that we could've written our own 
if we so chose. I can't think of any improvements for it off the top of my head.